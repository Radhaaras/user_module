<?php

namespace App\Http\Middleware;

use Closure;
use Cookie;
use Hash;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        
       // echo $request->path();     
        if ( Auth::check() ) {
            return redirect('/dashboard');
        }
        else{
            
           
                if(Auth::attempt(['email' => Cookie::get('rememberuseremail'), 'password' => Cookie::get('rememberuserpassword'), 'status' => 1])) {
                    $request->session()->put('email',Auth::user()->email);
                    $request->session()->put('password',Hash::Make(Auth::user()->password));
                    $request->session()->put('fullname',Auth::user()->fullname);
                    $request->session()->put('displayname',Auth::user()->displayname);
                    $request->session()->put('gender',Auth::user()->gender);
                    $request->session()->put('companyid',Auth::user()->companyid);
                    $request->session()->put('companycode',Auth::user()->companycode);
                    $request->session()->save();
                 
                    
                    
                    return redirect()->intended('/dashboard');
                }
            
              

        }
        return $next($request);
    }   

}
