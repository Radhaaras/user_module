<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;
use DB;
use Config; 
use Illuminate\Support\Facades\Route;
use Cache;
use Session;
use Closure;
use Cookie;

class CommonMenu
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       
       // echo $request->path();
        if( !Auth::check() ){
        
            if($request->path() != 'loginasnewuser'){
                
                if( Cookie::get('email')!='' ){
                   
                    return redirect('/logout');
                }else{
                   // return $next($request); 
                    return redirect('/login');
                }
                return $next($request); 
            }else{
              
                return $next($request); 
            }
            
            
        }else{
         
            if( Auth::user()->status == 0 ){
                Auth::logout();
               // Session::flush();
           }
           if( Auth::check() ){

            $user_role_permission = DB::table('users')
                ->join('roles', 'users.role', '=', 'roles.roleid')
                ->join('role_permissions', 'roles.roleid', '=', 'role_permissions.roleid')
                ->join('company', 'company.id', '=', 'users.companyid')
                ->where('users.status','=',1)
                ->where('users.email','=',Auth::user()->email)
                ->where('users.companyid','=',Auth::user()->companyid)
                ->orderBy('role_permissions.menuid', 'ASC')
                ->select('users.*', 'roles.*', 'role_permissions.*')
                ->get();
            
                view()->share('logedInuser', $user_role_permission);
                view()->share('dashboardMenu', Config::get('sidebarMenu'));           
                
                $current_route_name = $request->path();
                $result=DB::table('userlogs')
                    ->where('session_id',session()->getId())
                    ->update([
                    'last_active' => date('Y-m-d H:i:s'),
                    ]);
           }
                return $next($request); 
            }
        }
    
    public function find_key_value($array, $key, $val)
    {
        $i=0;
        foreach ($array as $item)
        {
            if (isset($array[$key]) && $array[$key] == $val) return true;
            if (isset($item[$key]) && $item[$key] == $val) return true;
            if (is_array($item) && $this->find_key_value($item, $key, $val)) return true;
    
            
        }
    
        return false;
    }
}

