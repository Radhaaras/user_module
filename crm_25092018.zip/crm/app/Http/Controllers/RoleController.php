<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Role;
use App\Model\RolePermission;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Crypt;

class RoleController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $roles = Role::orderBy('id','DESC')->paginate(5);
        return view('roles.index',compact('roles'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function createRole(){
        return view('pages.users.createRole');  
    }
    public function roleviewstatuschange(Request $request){
       // print_r($_POST);
       $pkt=explode('-',$_POST['rolestatus']);
        $roleid=$pkt[0];
        if($roleid!=1 && $roleid!=Auth::user()->role){
            if($pkt[1]==1){
                $status=0;
            }
            else{$status=1;}
            //echo $status;
            $result1=\DB::table('users') //check if user role already assigned
            ->where('role', $roleid)
            ->get()->toArray();
            //echo count($result1); 
            if(count($result1)){
                return response()->json(['error' => 'Role can not be Disabled, Role is already assigned to user']);
            }
            else{
                $result=DB::table('roles')
                ->where('roleid', $roleid)
                ->update([                    
                    'status' => $status,
                ]); 
            }
        }
        $user= \DB::table('users')->get();
        $role = \DB::table('roles')->get();
        return response()->json(['success' => 'Role Updated Successfully']);
        //return array(['role' => $role,'user' => $user]);
        
        

    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createRoleSave(Request $request){

        
        $rules = [
            'role_name' => 'required|unique:roles,rolename',
        ];
        $messsages = array(
            'role_name.required' => 'Enter Role Name',
            'role_name.unique' => 'Role name Exist',
            
        );
         
        $validator = Validator::make($request->all(), $rules, $messsages);
        
        if($validator->fails()){ 
             return redirect()->back()->withInput()->withErrors($validator);
        }
        $supervisor=0;
        $supervisor=array_key_exists ('supervisor' ,$_POST);

        $role = new Role;
        $role->companyid=$request->session()->get('companyid');
        $role->companycode=$request->session()->get('companycode');
        $role->rolename=$_POST['role_name'];
        $role->status=1;
        $role->created_by=Auth::User()->id;
        $role->updated_by='';
        $role->created_at=date('Y-m-d H:i:s');
        $role->updated_at=date('Y-m-d H:i:s');
        $roles=$role->save();
        $tmp=['dashboard','project','estimate','quotation','invoice','joborder','dnote','pr','clients','reports','employee','settings'];
        $access=['selectall','view','create','edit','print','delete'];
        for($i=0;$i<count($tmp);$i++){
            if (array_key_exists($tmp[$i], $_POST)) {
                $roleper = new RolePermission;
                $roleper->companyid=$request->session()->get('companyid');
                $roleper->companycode=$request->session()->get('companycode');
                $roleper->roleid=$role->id;
                $roleper->menuid=$i;
                for($k=0;$k<6;$k++){
                    if (array_key_exists($k, $_POST[$tmp[$i]])) {
                        //echo $k."  ".$tmp[$i]."<br>";
                        $aces=$access[$k];
                        $roleper->$aces=1;
                    }
                    else{
                        $aces=$access[$k];
                        $roleper->$aces=0;
                    }
                }
                $roleper->supervisor=$supervisor;
                $roleper->created_by=Auth::User()->id;
                $roleper->updated_by='';
                $roleper->created_at=date('Y-m-d H:i:s');
                $roleper->updated_at=date('Y-m-d H:i:s');
                $rolepermission[]=$roleper->save();
            }
        }
        $users= \DB::table('users')->get();
        $roles = \DB::table('roles')->get();
        $message='User Role "'.$_POST['role_name'].'" created successfully';
        //return redirect()->route('view.role')->with('success', $message);
        return redirect()->route('view.role')->with(['role' => $roles,'user' => $users,'success'=>$message]);
                    
    }
    public function viewRole(Request $request){
        $user= \DB::table('users')->get();
        $role = \DB::table('roles')->get();
       // print_r($role);
       // echo 'companyid '.$request->session()->get('companyid').' companycode '.$request->session()->get('companycode');
       // exit;
        return view('pages.users.viewRole')->with(['role' => $role,'user' => $user]);

    }  
    
    public function deleteRole($roleid,Request $request){
        $users = \DB::table('users')
        ->where('role','=',$roleid)
        ->get();
        $roles = \DB::table('roles')
        ->where('roleid','=',$roleid)
        ->get();
        $rolePermissions = \DB::table('role_permissions')
        ->where('roleid','=',$roleid)
        ->get();
        $user= \DB::table('users')->get();
        $role = \DB::table('roles')->get();
        if ($users->count()>0) {
            $message='Attempt to delete Role Failed, Role "'.$roles[0]->rolename.'"  is Assigned.';
            return redirect()->back()->with(['role' => $role,'user' => $user,'failed'=>$message]);
        }
        else{
            $roledelete = Role::where('roleid', '=', $roleid)->delete();
            //$roledelete = Role::find('roleid',$roleid);
            //$roledelete->delete();
            $rolePermissionDelete = RolePermission::where('roleid', '=', $roleid)->delete();
            $message='Attempt to delete Role "'.$roles[0]->rolename.'" Successful';
            return redirect()->back()->with(['role' => $role,'user' => $user,'success'=>$message]);
        }        
    }          
    public function editRole($roleid,Request $request){
        $roleid=Crypt::decrypt($roleid);
        
        $user = \DB::table('users')
        ->where('role','=',$roleid)
        ->get();
        $role = \DB::table('roles')
        ->where('roleid','=',$roleid)
        ->get();
        $rolepermission = \DB::table('role_permissions')
        ->where('roleid','=',$roleid)
        ->get();
        $active = 'User Management-role';
        return view('pages.users.editRole')->with(['roleid' => $roleid,'role' => $role,'user' => $user,'roleper' => $rolepermission,'active' => $active]);
    }
    public function viewRoleAdmin($roleid,Request $request){
        $roleid=Crypt::decrypt($roleid);
        
        $user = \DB::table('users')
        ->where('role','=',$roleid)
        ->get();
        $role = \DB::table('roles')
        ->where('roleid','=',$roleid)
        ->get();
        $rolepermission = \DB::table('role_permissions')
        ->where('roleid','=',$roleid)
        ->get();
        return view('pages.users.editroleadmin')->with(['roleid' => $roleid,'role' => $role,'user' => $user,'roleper' => $rolepermission]);
    }
    public function searchRoleAjax(Request $request){

        $search=$_POST['rolesearch'];
        $role='';
        if($search!=''){
            $role=DB::table('roles')
            ->where('rolename', 'LIKE', '%' . $search . '%')
            ->get();
        }
        else{
            $role=DB::table('roles')->get();
        }
         $user= \DB::table('users')->get();
         return array(['user' => $user, 'role' => $role]);


         
    }

    public function editRoleSave(Request $request ){
        
        
        $rules = [
            'role_name' => 'required|unique:roles,rolename,'.$request->roleid.',roleid',
        ];
        $messsages = array(
            'role_name.required' => 'Enter Role Name',
            'role_name.unique' => 'Role name Exist',
            
        );
        $validator = Validator::make($request->all(), $rules, $messsages);
        
        if($validator->fails()){ 
            
             return redirect()->back()->withInput()->withErrors($validator);
        }

       // print_r($_POST);
       // echo $_POST['supervisor']['0'];
       $supervisor=0;
       $supervisor=array_key_exists ('supervisor' ,$_POST);
       
       
        $roleid=$_POST['roleid'];
        $rolePermissionDelete = RolePermission::where('roleid', '=', $roleid)->delete();


        $result=DB::table('roles')
            ->where('roleid', $roleid)
            ->update([                    
                'companyid' => $request->session()->get('companyid'),
                'companycode' => $request->session()->get('companycode'),
                'rolename' => $_POST['role_name'],
                'status' => 1,
                'updated_by'=>Auth::User()->id,
                'updated_at'=>date('Y-m-d H:i:s'),
            ]);
            DB::table('role_permissions')->where('roleid', $roleid)->delete();

            $authuserid=Auth::User()->id;
            $tmp=['dashboard','project','estimate','quotation','invoice','joborder','dnote','pr','clients','reports','employee','settings'];
            $access=['selectall','view','create','edit','print','delete'];

            for($i=0;$i<count($tmp);$i++){
                if (array_key_exists($tmp[$i], $_POST)) {
                    $roleper = new RolePermission;
                    $roleper->companyid=$request->session()->get('companyid');
                    $roleper->companycode=$request->session()->get('companycode');
                    $roleper->roleid=$roleid;
                    $roleper->menuid=$i;
                    for($k=0;$k<6;$k++){
                        if (array_key_exists($k, $_POST[$tmp[$i]])) {
                            //echo $k."  ".$tmp[$i]."<br>";
                            $aces=$access[$k];
                            $roleper->$aces=1;
                        }
                        else{
                            $aces=$access[$k];
                            $roleper->$aces=0;
                        }
                    }
                    $roleper->supervisor=$supervisor;
                   $rolepermission[]=$roleper->save();
                }
            }

        $user= \DB::table('users')->get();
        $role = \DB::table('roles')->get();
        $message='You Just Edited '.$_POST['role_name'].' Role';
        //return redirect()->route('view.user')->with(['data' => $data, 'role' => $role])->with('success',$message);   
        return redirect('/viewrole')->with(['role' => $role,'user' => $user])->with('success',$message);


    }
              
   


    
}