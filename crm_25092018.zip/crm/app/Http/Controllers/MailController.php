<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;


class MailController extends Controller
{
    public function index(){
        //Mail::to($request->user())->send(new OrderShipped($order));
       Mail::to('radhaursm@gmail.com')->send(new Mailtrap(''));

    }
}
