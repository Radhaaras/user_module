<?php
namespace App\Http\Controllers\Auth;

//use App\Helpers\HttpHelper;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\MailController;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use DB;
use Validator;
use App\Model\User;
use App\Mail\Mailtrap;
use Illuminate\Mail\Mailer;
use Mail;
use App\Notifications\CustomPasswordReset;


class CustomPasswordController extends Controller
{   
    protected $redirectTo = '/dashboard';
    
    public function __construct() {
        //
    }

    /**
     * Show password reset form
     * @return type
     */
    public function showResetForm() {
        return view('forgot');
    }

    /**
     * Send reset password email
     * @return type
     */
    
    public function sendResetLinkResponse(Request $request) {
        
        $rules = [
            'email' => 'required|email|exists:users,email',
        ];
        $messsages = array(
            'email.required' => 'please Enter E-mail',
            'email.email' => 'Enter Valid E-mail',
            'email.exists' => 'E-mail does not exists',           
        );
       
        $validator = Validator::make($request->all(), $rules, $messsages);
        if($validator->fails()){ 
            $user = new user;
            return redirect()->back()->withInput()->withErrors($validator);
        }
        else{
            $user = User::where('email', request()->input('email'))->first();
            $user->notify(new CustomPasswordReset($request->session()->token()));
           
            return redirect()->back()->with('message', 'Password Reset link has been sent via mail!');
        }
        
    }
    public function showResetPasswordForm($token=null){
        $token;
        $userpkt = DB::table('users')->where('id', '1')->first(); 
        return view('auth.passwords.reset', compact('userpkt',$userpkt));
    }

    public function reset(Request $request) {
        $rules = [
            'email' => 'required|email|exists:users,email',
            'password' => 'required|required_with:password_confirmation|same:password_confirmation',
            
            
        ];
        $messsages = array(
            'email.required' => 'please Enter E-mail',
            'email.email' => 'Enter Valid E-mail',
            'email.exists' => 'E-mail does not exists',           
            'password.required' => 'Enter Valid E-mail',
            'password.required_with' => 'Please Enter confirm Password',           
            'password.same' => 'Confirm Password Does not match' 
            

        );
        //print_r($_POST);
        //exit;
        $validator = Validator::make($request->all(), $rules, $messsages);
        if($validator->fails()){ 
            return redirect()->back()->withInput()->withErrors($validator);
        }
        else{
            $hashPassword=Hash::make($request->password);
            $now=date('Y-m-d H:i:s');
            $ret=DB::table('users')
            ->where("users.id", '=',  $_POST['id'])
            ->update(['users.password'=> $hashPassword,'updated_at'=>$now]);
            return redirect('/')->with("status","Password has been changed. Please Login with the New Password!");
            
        }
    }
    
}