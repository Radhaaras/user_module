<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
//use App\Helpers\HttpHelper;
//use App\Traits\Throttles;
use Exception;
use Hash;
use Cookie;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Auth;
//use Illuminate\Support\Facades\Validator; 

//use App\Repositories\UserRepository;
use App\Model\User;
use App\Model\Role;
use DB;
use Validator;
use App\Model\Userlog;




class CustomAuthController extends Controller
{
    protected $redirectTo = '/dashboard';

    public function __construct() {
        //
    }

    protected function credentials(Request $request)
    {
        return [
            'email'=>$request->{$this->username()},
            'password'=>$request->password,
            'status'=>1

        ];
    }    
    /**
     * Show the main login page
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function showLogoutForm(Request $request){
        session()->forget('password');
        $fullname=session()->get('fullname');
        $displayname=session()->get('displayname');
        $gender=session()->get('gender');
        $email=session()->get('email');
        $data=array('fullname'=>$fullname, 'displayname'=>$displayname, 'gender'=>$gender, 'email'=>$email);
        return View::make('pages.logout', $data);
        //dd($data);
        //exit;
        //return view('pages.logout',compact('data'));
    }
    public function showLoginForm( ) {
        //Cache::flush();
        //Session::flush();
       // print_r(Auth::user());
        return view("index");
       
    }
    /**
     * Authenticate against the  API
     * @param AuthenticationRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function login(Request $request){
        
        
            $rules = [
                'email' => 'required|email|exists:users,email',
                'password' => 'required',             
            ];
            $messsages = array(
                'email.required' => 'please Enter E-mail',
                'email.email' => 'Enter Valid E-mail',
                'email.exists' => 'E-mail does not exists',
                'password.required' => 'Please Enter Password',          
            );
           // print_r($_POST);

           $remember='';
          /*  $remember = ($request->get('rememberme') == 1) ? true : false;
            //echo "rememner".$request->get('rememberme')."  ".$remember." <br>";
            //exit;
            if($remember==1){
                $exp = time()+2678400;
                Cookie::queue(Cookie::make('rememberuseremail', $request->email,$exp));
                Cookie::queue(Cookie::make('rememberuserpassword', $request->password,$exp));
                
                
            }
            */
            $validator = Validator::make($request->all(), $rules, $messsages);
            if($validator->fails()){ 
                
                $user = new user;
                return redirect()->back()->withInput()->withErrors($validator);
            }
            else{

                if(Auth::attempt(['email' => $request->email, 'password' => $request->password, 'status' => 1],0)) {
                    $exp = time()+2678400;
                    Cookie::queue(Cookie::make('email', Auth::user()->email,$exp));
                    Cookie::queue(Cookie::make('fullname', Auth::user()->fullname,$exp));
                    Cookie::queue(Cookie::make('displayname', Auth::user()->displayname,$exp));
                    Cookie::queue(Cookie::make('gender', Auth::user()->gender,$exp));
                    Cookie::queue(Cookie::make('profile_pic', Auth::user()->profile_picture,$exp));
                    Cookie::queue(Cookie::make('image_type',Auth::user()->image_type,$exp));

                    $request->session()->put('email',Auth::user()->email);
                    $request->session()->put('password',Hash::Make(Auth::user()->password));
                    $request->session()->put('fullname',Auth::user()->fullname);
                    $request->session()->put('displayname',Auth::user()->displayname);
                    $request->session()->put('gender',Auth::user()->gender);
                    $request->session()->put('companyid',Auth::user()->companyid);
                    $request->session()->put('companycode',Auth::user()->companycode);
                    $request->session()->save();
                    
                
                    $uselog = new Userlog;
                    $uselog->userid=Auth::user()->id;
                    $uselog->ipaddress=$request->getClientIp();
                    $uselog->session_id=session()->getId();
                    $uselog->login_at=date('Y-m-d H:i:s');
                    $uselog->last_active=date('Y-m-d H:i:s');
                    $uselog->created_at=date('Y-m-d H:i:s');
                    $uselog->status=0;
                    $insert=$uselog->save();
                      
                    
                    return redirect()->intended('/dashboard');
                }
                else{
                    
                    $result1=DB::table('users')
                    ->where('email', '=', $request->email)                    
                    ->get();
                    $result1 = $result1->toArray();
                       
                    if(count($result1)>0){
                        $hashedPassword = $result1[0]->password;
                        if($result1[0]->status==0 ){
                            return redirect()->back()->withInput($request->only('email' ))->with('error',"User not active ");
                        }
                        else if (!Hash::check($request->password, $hashedPassword)) {
                            return redirect()->back()->withInput($request->only('email'))->with('error','Wrong Password');
                        }
                        
                    }
                    
                }
            }
        }
         

        /**
     * Log user out
     * @param Request $request 
     * @return type
     */
    public function logout(Request $request) {
        $exp = time()+2678400;
        //print_r(Auth::user());
        if( Auth::check() ){
            Cookie::queue(Cookie::make('email', Auth::user()->email,$exp));
            Cookie::queue(Cookie::make('fullname', Auth::user()->fullname,$exp));
            Cookie::queue(Cookie::make('displayname', Auth::user()->displayname,$exp));
            Cookie::queue(Cookie::make('gender', Auth::user()->gender,$exp));
            Cookie::queue(Cookie::make('profile_pic', Auth::user()->profile_picture,$exp));
            Cookie::queue(Cookie::make('image_type',Auth::user()->image_type,$exp));
            Auth::logout();
            //Session::flush();
        }
       session()->forget('password');
        $fullname=session()->get('fullname');
        $displayname=session()->get('displayname');
        $gender=session()->get('gender');
        $email=session()->get('email');
        $profile_pic=session()->get('profile_picture');
        $image_type=session()->get('image_type');

        $data=array('fullname'=>$fullname, 'displayname'=>$displayname, 'gender'=>$gender, 'email'=>$email, 'profile_pic'=>$profile_pic, 'image_type'=>$image_type);
        
        $result=DB::table('userlogs')
        ->where('session_id',session()->getId())
        ->update([
        'logout_at' => date('Y-m-d H:i:s'),
        'status' => 0,
        ]);
        return view('pages.logout')->with('data',Cookie::get());
        //}
        //else{
         //   $this->showLoginForm();
       // }
        //return view('pages.logout')->withCookie(cookie('email','fullname','displayname'));
    }
    public function loginasnewuser(Request $request){
        $exp=0;
            Cookie::queue(Cookie::make('email','',$exp));
            Cookie::queue(Cookie::make('fullname','',$exp));
            Cookie::queue(Cookie::make('displayname','',$exp));
            Cookie::queue(Cookie::make('gender','',$exp));
            Cookie::queue(Cookie::make('profile_pic','',$exp));
            Cookie::queue(Cookie::make('image_type','',$exp));
        
        Session::flush();
       
        return redirect('/');
    }

   
}
