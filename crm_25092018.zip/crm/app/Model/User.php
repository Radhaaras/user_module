<?php

namespace App\Model;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        //'name', 'email', 'password',
        'companyid', 'companycode', 'fullname', 'displayname', 'gender', 'phone', 'otherphone', 'designation', 'email', 'password', 'role', 'cpr', 'cprexpiry', 'dob', 'nationality', 'passportnumber', 'passportexpiry', 'visaexpiry', 'dl', 'dlexpiry', 'paddress', 'pcity', 'pstate', 'pcountry', 'ppost', 'pcountrycode', 'pphonenumber','caddress', 'ccity', 'cstate', 'ccountry', 'cpost', 'ccountrycode', 'cphonenumber', 'status', 'profile_picture', 'image_type','signature', 'signature_type', 'created_by', 'updated_by', 'timestamp'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
         'remember_token',
    ];

    public function sendPasswordResetNotification($token)
    {
        $this->notify(new CustomPasswordReset($token));
    }
    
    
}
