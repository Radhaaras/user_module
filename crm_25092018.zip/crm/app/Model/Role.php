<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Role extends Model
{
    protected $fillable = [
        'id','date','rolename', 'status',
    ];

    public function role()
    {
        return $this->belongsTo(User::class, 'role');
    }
    
}