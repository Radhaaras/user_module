<?php

use Illuminate\Database\Seeder;

class RolePermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
           // DB::table('roles')->delete();
            DB::table('role_permissions')->insert(array(
                array('id'=>1,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>0,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>2,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>1,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>3,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>2,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>4,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>3,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>5,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>4,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>6,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>5,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>7,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>6,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>8,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>7,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>9,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>8,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>10,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>9,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>11,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>10,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>12,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>11,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                array('id'=>13,'companyid'=>1,'companycode'=>'AKIT', 'roleid'=>1,'menuid'=>12,'selectall'=>1,'view'=>1,'create'=>1,'edit'=>1,'delete'=>1,'print'=>1,'created_by'=>'system','updated_by'=>'system','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')),
                
        ));
    }
}
