<?php

use Illuminate\Database\Seeder;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //DB::table('roles')->delete();
        //insert some dummy records
        DB::table('roles')->insert(array(
            array(
                'roleid'=>1,
                'companyid'=>1,
                'companycode'=>'AKIT', 
                'rolename'=>'Superadmin', 
                'status'=>1,
                'created_by'=>'system', 
                'Updated_by'=>'system', 
                'created_at'=>date('Y-m-d H:i:s'), 
                'updated_at'=>date('Y-m-d H:i:s')                    
            ),
        ));
    }
}
