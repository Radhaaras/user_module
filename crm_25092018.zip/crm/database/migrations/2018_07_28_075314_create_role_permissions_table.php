<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRolePermissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::create('role_permissions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('companyid');
            $table->string('companycode');
            $table->integer('roleid');
            $table->integer('menuid');
            $table->integer('selectall');
            $table->integer('view');
            $table->integer('create');
            $table->integer('edit');
            $table->integer('print');
            $table->integer('delete');
            $table->string('created_by')->nullable();
            $table->string('updated_by')->nullable();
            $table->timestamps();
            $table->index(['id','roleid', 'menuid']);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('role_permissions');
    }
}
