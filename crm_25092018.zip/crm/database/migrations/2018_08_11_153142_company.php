<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Company extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company', function (Blueprint $table) {
            $table->increments('id');
            $table->string('companyname');
            $table->string('companycode');
            $table->string('priority')->nullable();
            $table->string('logo')->nullable();
            $table->string('logo_type')->nullable();
            $table->date('registered')->nullable();
            $table->date('renewed')->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
            $table->index(['id']);  
        });
    }
    
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
