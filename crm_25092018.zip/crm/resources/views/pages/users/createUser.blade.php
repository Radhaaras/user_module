
@extends('layouts.app')


@section('content')
<style>
.field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}

.container{
  padding-top:10px;
  margin: auto;
}

</style>
<script>
	/*var $li = $('.nav-tabs').find('li'),
        i = $li.siblings('.active').index(),
        max = $li.length;

    if (i < max) {
      $li.find('[role="tab"]').eq(i+1).tab('show');
    }
	*/


/*
$(function() {
    $('#upload_dp').checkFileType({
        allowedExtensions: ['jpg', 'jpeg','png'],
        success: function() {
            
        },
        error: function() {
            alert('Upload Image');
        }
    });

});
/*
$('form').validate({
    rules: {
        upload_dp: {
            minlength: 3,
            maxlength: 15,
            required: true
        },
        lastname: {
            minlength: 3,
            maxlength: 15,
            required: true
        }
    },
    highlight: function(element) {
        $(element).closest('.form-group').addClass('has-error');
    },
    unhighlight: function(element) {
        $(element).closest('.form-group').removeClass('has-error');
    }
});
*/

	
$(document).ready(function() {
	
	jQuery('#tablist a[href="#{{ old('tab') }}"]').tab('show');
	var hash = window.location.hash;
	console.log(hash);
	if( hash.length > 1 )
		jQuery('#tablist a[href="'+hash+'"]').tab('show');
		//$('ul'+hash+':first').show();

	//var tmp $('#tablist li').find('active');
	//alert(tmp);
	
	function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
			$('#deleteImage').removeAttr('hidden');
			
        }
    }
	$(function (){
		
		$('#deleteImage').on('click', function(){
			var gender=$("#gender").val();
			$('#blah').attr('src', '/assets/img/profiles/user.jpg');
			$('#deleteImage').attr("hidden", true)
			$('#upload_dp').val('');
			
		})
   })
	var olddataArray=[];
	$(function(){
	var $img       = $("#my_image17")
		, $container = $("#iii");
		$img.on("click", function() {
			$img.remove();
			$container.html("<embed  src='http://www.leconcombre.com/stock/coccyminimini1.swf' width='550'  height='400'/>");
			$container.removeClass().removeAttr("id");
		});
	});
    
    $("#upload_dp").change(function(){
        readURL(this);
    });
	
	$(".toggle-password").click(function() {
		$(this).toggleClass("fa-eye fa-eye-slash");
		var input = $($(this).attr("toggle"));
		if (input.attr("type") == "password") {
			input.attr("type", "text");
		} else {
			input.attr("type", "password");
		}
	});

	$('#basicDetails').click(function(){
		var $pkt=$("#form_traditional_validation").serialize();
		console.log($pkt);
		$.ajax({
           type: "post",
           url: "{{ route('user.validation.ajax') }}",
		   data:{'pkt':$pkt,"_token": "{{ csrf_token() }}", },
		   dataType:'json',
		   success: function(data)
           {
			  if(data.status == 422) {
				  console.log('old array'+olddataArray);
				  var oldmessagelength =Object.keys(olddataArray).length;
					if(oldmessagelength>0){
						$.each(olddataArray, function (key, value) {
							console.log(key+"  "+value);
							$("#e" + key).html('');
							$("#" +key).addClass('valid');
							$("#" +key).removeClass('error');
						});
				}
				var errors = data.errors;
				//console.log(errors);	
				olddataArray=data.errors;
				console.log(olddataArray);
				$.each(data.errors, function (key, value) {
					$("#e" + key).html(value);
					console.log()
					$("#" +key).removeClass('valid');
					$("#" +key).addClass('error');
				});
			}
			else if(data.status == 200){
				var oldmessagelength =Object.keys(olddataArray).length;
					if(oldmessagelength>0){
						$.each(olddataArray, function (key, value) {
							console.log(key+"  "+value);
							$("#e" + key).html('');
							
							

						});
				}

				console.log('success');
				jQuery('#tablist a[href="#roles"]').tab('show');			
				
			}	
		},
		 error: function (jqXHR, textStatus, errorThrown) {
			// console.log(textStatus);
			  	//var data = $.parseJSON(jqXHR.responseText);
				var data =jqXHR.responseText;
				console.log(data);
				if (data.errors) {
					var errors = data.errors;
					console.log(errors);	
					$.each(data.errors, function (key, value) {
						$("#e" + key).html(value);
					});
					
				}
		   }
		})
         

		
	});

		
	
});


$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(function(){ // this will be called when the DOM is ready
        $('#role').on('change', function(){
            var role=$('#role').val();
			$.ajax({
				type: 'POST',
				url: "{{ route('update.role.ajax') }}",
				data: {'roleselected':role,"_token": "{{ csrf_token() }}", },
				dataType: "json",
				success: function( data ) {
					viewGenerator(data);
				}       
			})			
		});
    });
   
    function viewGenerator(data){
        $("#displayTable").empty()
        var pkt = $.parseJSON(JSON.stringify(data));
        roles=pkt[0]['role'];
        rolepermission=pkt[0]['roleprm'];
		var rolelength=Object.keys(roles).length;
		var roleplength=Object.keys(rolepermission).length;
		//console.log(roles);
		//console.log(rolepermission);
		//console.log(rolepermission)->menuid;
console.log(roleplength);
        var pktdump="";
		var tmp=['Dashboard','Project','Estimate','Quotation','Invoice','Joborder','Delivery Note','Payment and  Receipt','Clients','Reports','Employee','Settings','Supervisor'];
        var access=['selectall','view','create','edit','print','delete'];
			if(roleplength>0){
				pktdump+="<h4>Permission Assigned to this Role</h4><table class='table'><thead><tr><th>Access to</th><th style='width: 7%;' class='text-center'>Select All</th><th style='width: 7%;' class='text-center'>View</th><th style='width: 7%;' class='text-center'>Create</th><th style='width: 7%;' class='text-center'>Edit</th><th style='width: 7%;' class='text-center'>Print</th><th style='width: 7%;' class='text-center'>Delete</th></tr></thead><tbody id='tbodydisplay'>";	
				for(var i=0;i<roleplength;i++){
					if(rolepermission[i]['menuid']==11 || rolepermission[i]['menuid']==12){
							pktdump+="<tr><td class='v-align-middle'>"+tmp[rolepermission[i]['menuid']]+"</td>";
							if(rolepermission[i]['selectall']==1){
								pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
					
							}
							else{
								pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
							}
					}
					else{
					console.log(rolepermission[i]['menuid'])
					pktdump+="<tr><td class='v-align-middle'>"+tmp[rolepermission[i]['menuid']]+"</td>";
					if(rolepermission[i]['selectall']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
					if(rolepermission[i]['view']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
					if(rolepermission[i]['create']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
					if(rolepermission[i]['edit']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
					if(rolepermission[i]['print']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
					if(rolepermission[i]['delete']==1){
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons allowed'>check</i></label></td>";
			
					}
					else{
						pktdump+="<td class='v-align-middle'><label class='show-role'><i class='material-icons not-allowed'>error_outline</i></label></td>";
					}
				}
					pktdump+="</tr>";
			}//forloop
		}
        $('#displayTable').append(pktdump);
		
    }
	$(function(){ 
		
		$(".disabled").click(function(e){
			e.preventDefault();
			if ($(this).hasClass('disabled')) {
				return false;
			}
		});
		

	});





</script>

		<div class="page-content">
		<?php
			//print_r($roleTable);
		?>
			<div class="content">
					@if (session()->has('success'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('success') }}</strong>
						</span>
					</div>
					@endif

				<ul class="breadcrumb">
					<li><a href="{{ route('view.user') }}">&larr; View Users</a>
					</li>
				</ul>

				<div class="page-title m-t-30">
					<h3><i class="far fa-user">+</i> Create User</h3>
				</div>


				<div class="col-sm-12 col-md-12 col-lg-12" id='tabs'>
					<ul class="nav nav-tabs" role="tablist" id='tablist'>
						<li class="active">
							<a href="#basicdetails" role="tab"  data-toggle="tab" aria-expanded="true" id='basicdetails_tab'> Basic Details</a>
						</li>
						<li class="disabled">
							<a href="#roles" role="tab" id='rolestab' data-toggle="tab" aria-expanded="false"  id='roles_tab'>Roles</a>
						</li>
					</ul>

					<div class="tab-content">

						<div class="tab-pane active" id="basicdetails">
							<div id="user-profile" class="row">
								<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="far fa-address-card"></i> Basic Details</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<div class="row">

											<form action="{{ route('create.user.saving') }}" autocomplete="off" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data" >	
												{{ csrf_field() }}
												
												<div class="col-sm-12 col-md-12 col-lg-2 m-b-30">
													<div class="widget-item edit-user-profile ">
                                                            <div class="tiles">
                                                                    <div class="tiles-body no-padding" id='imgparent'>
                                                                            <img id="blah" src="/assets/img/profiles/user.jpg" alt="Profile Image" />
																			<div class='clearfix'></div>
                                                               			 <a   class='dp-delete-icon' ><i id='deleteImage' class='far fa-trash-alt' hidden></i></a>
                                                                            <div class="overlayer bottom-right fullwidth">
                                                                                    <div class="overlayer-wrapper">
                                                                                            <div class="p-l-20 p-r-20 p-b-20 p-t-20 text-center">
                                                                                                    <div class="dp-upload-icon"><i class="fa fa-camera"></i></div>
                                                                                                    <input name="upload_dp" type="file" id='upload_dp' class="upload-dp" title="Upload your picture" />
																									<div class="clearfix"></div>
																									<!-- <input type='button' id='deleteImage' value='delete' hidden/> -->
                                                                                            </div>																			
                                                                                    </div>
																					
                                                                            </div>
                                                                    </div>
																	<small class="text-danger error" id='eupload_dp' >{{ $errors->first('upload_dp') }}</small>	
                                                            </div>
													</div>
													<p class='help text-center m-t-10'>Recommended size is 300 X 300</p>
												</div>
	
                                                    <div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">
														<div class="hidden">
															<div class="slide-primary">
																<input type="checkbox" name="switch" class="ios" checked="checked" />
															</div>
															<div class="slide-success">
																<input type="checkbox" name="switch" class="iosblue" checked="checked" />
															</div>
														</div>
														
                                                    	<div class="form-group">
															<label class="form-label">Full Name</label>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('fullname') ) ? 'error' : '' }}"  aria-invalid="false"  aria-invalid="" name="fullname" id="fullname" type="text" value="{{ old('fullname') }}" >
                                                                <small class="text-danger" id='efullname'>{{ $errors->first('fullname') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Display Name</label>
															<span class="help">"Preferred name to display"</span>
															<div class="controls">
																<input class="form-control {{  ( $errors->first('displayname') ) ? 'error' : '' }}"  aria-invalid="false"  aria-invalid="" name="displayname" id="displayname" type="text" value="{{ old('displayname') }}" >
                                                                <small class="text-danger" id='edisplayname'>{{ $errors->first('displayname') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Gender</label>
															<div class="controls">
																<select name="gender" id="gender" class="select1 form-control" aria-required="true" aria-invalid="false" aria-describedby="form3Gender-error" value="{{ old('username') }}" >
																	<option  value="">Select</option>
																	<option value="male">Male</option>
																	<option value="female">Female</option>
																</select>
                                                                <small class="text-danger" id="egender">{{ $errors->first('gender') }}</small>
															</div>
														</div>
                                                        <div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">Mobile Number</label>
																<input class="form-control" name="phone" id="phone" type="number" value="{{ old('phone') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id='ephone'>{{ $errors->first('phone') }}</small>
															</div>
															<div class="col-md-6">
																<label class="form-label">Other Phone</label>
																<input class="form-control" name="otherphone" id="otherphone" type="number" value="{{ old('otherphone') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id="eotherphone">{{ $errors->first('otherphone') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Email</label>
															<span class="help">"This email ID is going to be the username"</span>
															<div class="controls">
																<input class="form-control" name="email" id="email" type="text" value="{{ old('email') }}" >
                                                                <small class="text-danger" id="eemail">{{ $errors->first('email') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Password</label>
															<span class="help">"User can change the password later from their account settings"</span>
															<div class="controls">

																<input class="form-control {{  ( $errors->first('password') ) ? 'error' : '' }}"  aria-invalid="false"  aria-invalid="" name="password" id="password-field" type="password" value="{{ old('password') }}" >
																<span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                                <small class="text-danger" id='epassword'>{{ $errors->first('password') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Designation</label>
															<div class="controls">
																<input class="form-control  input-append " name="designation" type="text"  placeholder="" value="{{ old('designation') }}" >
                                                                <small class="text-danger" id="edesignation">{{ $errors->first('designation') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">National ID</label>
															<span class="help">"CPR number"</span>
															<div class="controls">
																<input type="number" class="form-control" name='cpr' value="{{ old('cpr') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id='ecpr'>{{ $errors->first('cprno') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">National ID Expiry Date</label>
															<span class="help">"CPR Expiry Date"</span>
															<div class="controls">
																<input type="text"  class="form-control expdate" placeholder="DD-MM-YYYY" name='crpexpiry' value="{{ old('crpexpiry') }}" >
																<small class="text-danger" id='ecrpexpiry'>{{ $errors->first('crpexpiry') }}</small>
															</div>
														</div>


														

														<div class="form-group">
															<label class="form-label">Date of Birth</label>
															<div class="controls">
																<input class="form-control  input-append date  expdate" name="dob" type="text"  placeholder="DD-MM-YYYY" value="{{ old('dob') }}" width="276"  >
                                                                <small class="text-danger" id="edob">{{ $errors->first('dob') }}</small>
															</div>
														</div>
														
														<div class="form-group">
															<label class="form-label">Nationality</label>
															<div class="controls">
																<input class="form-control " name="nationality" type="text" value="{{ old('nationality') }}">
                                                                <small class="text-danger" id="enationality">{{ $errors->first('nationality') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Passport Number</label>
															<div class="controls">
																<input class="form-control" name="passportnumber" type="text" value="{{ old('passportnumber') }}" minlength="4" maxlength="15">
                                                                
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Passport Expiry Date</label>
															<div class="controls">
																<input class="form-control expdate" name="passportexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ old('passportexpiry') }}">
                                                                <small class="text-danger" id="epassportexpiry">{{ $errors->first('passportexpiry') }}</small>
															</div>
														</div>
                                                        
														
													</div>


													<div class="col-sm-12 col-md-12 col-lg-5 p-l-30 p-r-30">


														<div class="form-group">
															<label class="form-label">Visa Valid Until</label>
															<div class="controls">
																<input class="form-control expdate" name="visaexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ old('visaexpiry') }}">
                                                                <small class="text-danger" id="evisaexpiry">{{ $errors->first('visaexpiry') }}</small>
															</div>
														</div>
														<div class="form-group">
															<label class="form-label">Driving License</label>
															<div class="controls">
																<input class="form-control" name="dl" type="text"  value="{{ old('dl') }}">
                                                                
															</div>
														</div>
														<div class="form-group">
															<label class="form-label ">Driving License Expiry Date</label>
															<div class="controls">
																<input class="form-control expdate" name="dlexpiry" type="text"   placeholder="DD-MM-YYYY" value="{{ old('dlexpiry') }}" >
                                                                <small class="text-danger" id="edlexpiry">{{ $errors->first('dlexpiry') }}</small>
															</div>
														</div>
														<br>
														<h4>Permanent Addess</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="paddress" type="text" value="{{ old('paddress') }}" >
                                                               
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="pcity" type="text"  value="{{ old('pcity') }}">
                                                                
															</div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="pstate" type="text"  value="{{ old('pstate') }}">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="pcountry" type="text"  value="{{ old('pcountry') }}">
                                                                
															</div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="ppost" type="number" value="{{ old('ppost') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control" name="pcountrycode" type="number" value="{{ old('pcountrycode') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id="epcountrycode">{{ $errors->first('pcountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
																<input class="form-control" name="pphonenumber" type="number" value="{{ old('pphonenumber') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id="epphonenumber">{{ $errors->first('pphonenumber') }}</small>
															</div>
														</div>



														<br>
														<h4>Current Addess</h4>
														<div class="row form-row">
															<div class="col-md-12">
																<label class="form-label">Address</label>
																<input class="form-control" name="caddress" type="text"  value="{{ old('caddress') }}">
                                                               
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-6">
																<label class="form-label">City</label>
																<input class="form-control" name="ccity" type="text"  value="{{ old('ccity') }}">
                                                                
															</div>
															<div class="col-md-6">
																<label class="form-label">State</label>
																<input class="form-control" name="cstate" type="text"  value="{{ old('cstate') }}">
                                                                
															</div>
														</div>
														<div class="row form-row">
															<div class="col-md-8">
																<label class="form-label">Country</label>
																<input class="form-control" name="ccountry" type="text"  value="{{ old('ccountry') }}">
                                                               
															</div>
															<div class="col-md-4">
																<label class="form-label">Postal Code</label>
																<input class="form-control" name="cpost" type="text" value="{{ old('cpost') }}">
                                                                
															</div>
														</div>
                                                        <div class="row form-row">
															<div class="col-md-4">
																<label class="form-label">Country Code</label>
																<input class="form-control" name="ccountrycode" type="number" value="{{ old('ccountrycode') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id="eccountrycode">{{ $errors->first('ccountrycode') }}</small>
															</div>
															<div class="col-md-8">
																<label class="form-label">Phone Number</label>
																<input class="form-control" name="cphonenumber" type="number" value="{{ old('cphonenumber') }}" onkeydown="javascript: return event.keyCode == 69 ? false : true">
                                                                <small class="text-danger" id="ecphonenumber">{{ $errors->first('cphonenumber') }}</small>
															</div>
														</div>




													</div>


													<div class="col-sm-12 m-t-50 m-b-30">
													<a class="btn btn-primary btn-cons pull-right"   id='basicDetails'><i class="fa fa-save"></i>Next</a>
													<!--	<button class="btn btn-primary btn-cons pull-right" name="form1" href='#roles' ><i class="fa fa-save"></i> Next</button>-->
													</div>

												<!--</form>-->
											</div>
										</div>
									</div>
								</div>






							</div>
						</div>


						<div class="tab-pane" id="roles">
							<div class="row">
								<div class="col-sm-12">
									<div class="grid simple">
										<div class="grid-title no-border">
											<h4><i class="fa fa-plug"></i> Roles</span></h4>
										</div>
										<div class="grid-body no-border">
											<br>
											<div class="row">
										<!--	<form action="{{ route('create.user.saving') }}" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data" >	
												{{ csrf_field() }}-->
											<?php 
										//	$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
										//	if (strpos($actual_link,'userid') !== false) {
										//		$temp=explode('/',$_SERVER['QUERY_STRING']);
										//		$temp1=explode('=',$temp[0]);
											//	echo $temp1[1]."<br>";
										//	echo "<input type='hidden' value='".$temp1[1]."' id='userid' name='userid' />";
										//	} 	
											?>
												
												
												
												<div class="col-sm-12 col-md-12 col-lg-4 p-l-30 p-r-30">

													<h4>Choose a role to asign for this user</h4>
													<div class="form-group">
														<div class="controls">
														<?php //print_r('roleTable'); ?>
														
															<select name="role" id="role" class="select1 form-control"  aria-required="true" aria-invalid="false" aria-describedby="form3Gender-error" required>
																<option selected value=''>Select</option>
																<?php	
																foreach($roleTable as $roles){
																	echo "<option value=".$roles->roleid .">".$roles->rolename."</option>";
																}
															?>	
																
																
																
															</select>
															
														</div>
													</div>
													<button type="submit" class="btn btn-primary btn-cons" name="form2"><i class="fa fa-save"></i> Save</button>

												</div>
											</form>

													<div class="col-sm-12 col-md-12 col-lg-8 p-l-30 p-r-30">
														
														<div id='displayTable'></div>
														
						<!--	<table class="table">
								<thead>
								  <tr>
									
									<th>Access to</th>
									<th style="width: 7%;" class="text-center">Select All</th>
									<th style="width: 7%;" class="text-center">View</th>
									<th style="width: 7%;" class="text-center">Create</th>
									<th style="width: 7%;" class="text-center">Edit</th>
									<th style="width: 7%;" class="text-center">Print</th>
									<th style="width: 7%;" class="text-center">Delete</th>
								  </tr>
								</thead>
								<tbody id='tbodydisplay'>
								  
									<tr>
										<td class="v-align-middle">Projects</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
								  <tr>

										

										<td class="v-align-middle">Estimation</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
								  <tr>

										

										<td class="v-align-middle">Quotation</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										

										<td class="v-align-middle">Invoice</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>

										

										<td class="v-align-middle">Job Order</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>

										

										<td class="v-align-middle">Delivery Note</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
					
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										

										<td class="v-align-middle">Payment Receipt</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
								
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
									
									<tr>

										

										<td class="v-align-middle">Clients</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										

										<td class="v-align-middle">Reports</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										

										<td class="v-align-middle">Employee Management</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>


										<td class="v-align-middle">Settings</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>
										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons allowed">check</i>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="show-role">
												<i class="material-icons not-allowed">error_outline</i>
											</label>
										</td>
									  
								  </tr>
									
									
								
									
									



								</tbody>
							  </table>-->
													</div>


											</div>
										</div>
									</div>
								</div>
							</div>
						</div>


					</div>
				</div>




			</div>
		</div>




	</div>
    @endsection


</body>
</html>
