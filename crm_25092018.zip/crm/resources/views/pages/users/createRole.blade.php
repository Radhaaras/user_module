
@extends('layouts.app')
@section('content')
<script>
var items = [];
$(document).ready(function(){
	$('.checkAll').click(function(event) {  //on click 
		var $boxes = $(this).closest('tr').find('input[type="checkbox"]');  
		if(this.checked) { // check select status
			$boxes.each(function() { //loop through each checkbox
				this.checked = true;  //select all checkboxes                
			});
		}else{
			$boxes.each(function() { //loop through each checkbox
				this.checked = false; //deselect all checkboxes under the checkAll checkbox                      
			});         
		}
		
		
	});
	$('.checkNone').click(function(event) {  //on click 
	var i=0;
		$(this).closest('tr').find('.checkNone').each(function() { //loop through each checkbox
			//console.log(i);
			if(this.checked){
				i=i+1;
			}
			if(i==5){
				$(this).parent().parent().parent().find('input:checkbox:first').prop( "checked",true);
			}
			else{
				$(this).parent().parent().parent().find('input:checkbox:first').prop( "checked",false);
			}			
		}); 
	});
	
})


</script>
	<div class="page-content">
			<div class="content">
				@if (session()->has('success'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('success') }}</strong>
						</span>
					</div>
					@endif
				<div id="role-settings" class="row">
					<div class="container">
						<div class="page-title">
						<h3><i class="fa fa-bolt"></i> Create Role</h3>
					</div>
					<form action="{{ route('create.role.saving') }}" autocomplete="off" id="form_traditional_validation" method='post' class="validate" enctype="multipart/form-data" >	
												{{ csrf_field() }}
												
						<div class="col-sm-12">
						  <div class="grid simple ">

							<div class="grid-body no-border role-creating-table">
								
								<input type="text" class="role-name" placeholder="Type a new role name" id='role_name' name='role_name' required minlength="4" maxlength="30" value="{{ old('role_name') }}" />
								<p><small class="text-danger">{{ $errors->first('role_name') }}</small></p>

							  <table class="table">
								<thead>
								
								  <tr>
									<th style="width: 15%;">Full Control</th>
									<th>Access to</th>
									<th style="width: 7%;" class="text-center">View</th>
									<th style="width: 7%;" class="text-center">Create</th>
									<th style="width: 7%;" class="text-center">Edit</th>
									<th style="width: 7%;" class="text-center">Print</th>
									<th style="width: 7%;" class="text-center">Delete</th>
								  </tr>
								</thead>
								<tbody>
								<tr>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox"  name='dashboard[0]'  id='dashboard[0]' value='all' class='checkAll'>
											<span class="slider-create-role" ></span>
										</label>
									</td>

									<td class="v-align-middle">Dashboard</td>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox" name='dashboard[1]' id='dashboard[1]' value='view' class='checkNone'>
											<span class="slider-create-role"></span>
										</label>  
									</td>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox" name='dashboard[2]' id='dashboard[2]' value='create' class='checkNone'>
											<span class="slider-create-role"></span>
										</label>
									</td>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox" name='dashboard[3]' id='dashboard[3]' value='edit' class='checkNone'>
											<span class="slider-create-role"></span>
										</label>
									</td>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox" name='dashboard[4]' id='dashboard[4]' value='print' class='checkNone'>
											<span class="slider-create-role"></span>
										</label>
									</td>

									<td class="v-align-middle">
										<label class="create-role-switch">
											<input type="checkbox" name='dashboard[5]' id='dashboard[5]' value='delete' class='checkNone'>
											<span class="slider-create-role"></span>
										</label>
									</td>

									</tr>
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='project[0]'  id='project[0]' value='all' class='checkAll'>
												<span class="slider-create-role" ></span>
											</label>
										</td>

										<td class="v-align-middle">Projects</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox" name='project[1]' id='project[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox" name='project[2]' id='project[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox" name='project[3]' id='project[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox" name='project[4]' id='project[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox" name='project[5]' id='project[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
								  <tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[0]'  id='estimate[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Estimation</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[1]'  id='estimate[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[2]'  id='estimate[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[3]'  id='estimate[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[4]'  id='estimate[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='estimate[5]'  id='estimate[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
								  <tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[0]'  id='quotation[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Quotation</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[1]'  id='quotation[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[2]'  id='quotation[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[3]'  id='quotation[3]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[4]'  id='quotation[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='quotation[5]'  id='quotation[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[0]'  id='invoice[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Invoice</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[1]'  id='invoice[1]'  value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[2]'  id='invoice[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[3]'  id='invoice[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[4]'  id='invoice[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='invoice[5]'  id='invoice[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[0]'  id='joborder[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Job Order</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[1]'  id='joborder[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[2]'  id='joborder[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[3]'  id='joborder[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[4]'  id='joborder[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='joborder[5]'  id='joborder[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[0]'  id='dnote[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Delivery Note</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[1]'  id='dnote[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[2]'  id='dnote[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[3]'  id='dnote[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[4]'  id='dnote[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='dnote[5]'  id='dnote[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[0]'  id='pr[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Payment Receipt</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[1]'  id='pr[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[2]'  id='pr[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[3]'  id='pr[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[4]'  id='pr[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='pr[5]'  id='pr[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='clients[0]'  id='clients[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Clients</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='clients[1]'  id='clients[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='clients[2]'  id='clients[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='clients[3]'  id='clients[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch ">
												<input type="checkbox"  name='clients[4]'  id='clients[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='clients[5]'  id='clients[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='reports[0]'  id='reports[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Reports</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='reports[1]'  id='reports[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='reports[2]'  id='reports[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch ">
												<input type="checkbox"  name='reports[3]'  id='reports[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='reports[4]'  id='reports[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch ">
												<input type="checkbox"  name='reports[5]'  id='reports[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='employee[0]'  id='employee[0]' value='all' class='checkAll'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Employee Management</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='employee[1]'  id='employee[1]' value='view' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>  
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='employee[2]'  id='employee[2]' value='create' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='employee[3]'  id='employee[3]' value='edit' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch ">
												<input type="checkbox"  name='employee[4]'  id='employee[4]' value='print' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='employee[5]'  id='employee[5]' value='delete' class='checkNone'>
												<span class="slider-create-role"></span>
											</label>
										</td>
									  
								  </tr>
									
									
									<tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='settings[0]'  id='settings[0]'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Settings</td>

										<td class="v-align-middle">
											 
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>
									  
								  </tr>
									
								  <tr>

										<td class="v-align-middle">
											<label class="create-role-switch">
												<input type="checkbox"  name='supervisor[0]'  id='supervisor[0]'>
												<span class="slider-create-role"></span>
											</label>
										</td>

										<td class="v-align-middle">Supervisor</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

										<td class="v-align-middle">
											
										</td>

									</tr>

									
								
									
									



								</tbody>
							  </table>
								
								<!--<a href="" class="btn btn-save pull-right">Save</a>-->
								<button type='submit' class="btn btn-save pull-right">Save</a>
								
							</div>
						  </div>
						</div>
						</form>
						
						
					</div>
					
					



				</div>
				
				
				
				
			</div>
		</div>
		
		
		

	</div>

	
	@endsection
</body>
</html>