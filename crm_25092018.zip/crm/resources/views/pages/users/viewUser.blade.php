@extends('layouts.app')


@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">


	<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(function(){ // this will be called when the DOM is ready
        $('#userSearch').keyup(function() {
            var searchstr=$('#userSearch').val();
            //var url='{{ route("user.search", ":slug") }}';
            //url = url.replace(':slug', searchstr);
            $.ajax({
                type: 'POST',
                url: "{{ route('user.search.ajax') }}",
                data: {'searchString' :searchstr },
                dataType: "json",
                success: function( data ) {
                   // var pkt=$.parseJSON(data);
                    viewGenerator(data);
                }       
            })

        });
    });
   
    function viewGenerator(data){
        $("#users").empty()
        var pkt = $.parseJSON(JSON.stringify(data));
        //console.log(pkt);
        var data=pkt[0]['data'];
        var role=pkt[0]['role'];
        var length=Object.keys(data).length;
        var rolelength=Object.keys(role).length;
        var pktdump='';
        for(var i=0;i<length;i++){
           
            var rolename='';
            pktdump+="<div class='col-sm-12 col-md-4 col-lg-3 m-b-30'><div class='widget-item user'><div class='tiles user-dp'> <div class='tiles-body no-padding'><a href=''>";
             if(data[i]['profile_picture']){
                pktdump+="<img src='"+ data[i]['profile_picture'] +"' alt=''>";
            }
            else if(data[i]['gender']=='male'){
                pktdump+="<img src='/assets/img/profiles/male-user.jpg' alt=''>";
            }
            else{
                pktdump+="<img src='/assets/img/profiles/female-user.jpg' alt=''>";
            }                                      
            pktdump+="</a><div class='overlayer bottom-right fullwidth'><div class='overlayer-wrapper'><div class=' p-l-20 p-r-20 p-b-20 p-t-20'><div>";
            if(data[i]['role']!=''){
                for(j=0;j<rolelength;j++){
                    if(parseInt(data[i]['role'])==parseInt(role[j]['roleid'])){
                        rolename= role[j]['rolename']; 
                    }
                } 
            }
            var id=data[i]['id'];
            var $parameter= "<?php echo Crypt::encrypt("+id+"); ?>";
            pktdump+="</div><div class='pull-right'> <a href='{{route('edit.user','')}}/"+$parameter+"' class='hashtags'>"+ rolename +" </a> </div>";
            pktdump+="<div class='clearfix'></div></div></div></div><br></div></div><div class='tiles white body-tiles '>";
            pktdump+="<div class='tiles-body'><div class='row'><div class='user-comment-wrapper pull-left'><div class='comment'><div class='user-name text-black bold'>"+data[i]['displayname']+" </div>";
            pktdump+="<div class='preview-wrapper'>"+data[i]['designation']+"</div></div><div class='clearfix'></div></div>";                                          
            pktdump+="<div class='clearfix'></div><div class='p-l-15 p-t-10 p-r-20'><p>"+data[i]['phone']+"</p><p><a >"+data[i]['email']+"</a></p>";
            pktdump+="<div class='post p-t-10 p-b-10'><div class='view-btn'><a href='{{route('edit.user','')}}/"+$parameter+"' class='btn button'>Edit</a></div>";
            pktdump+="<div class='clearfix'></div></div></div></div></div></div></div></div>";

        }//forloop
        $('#users').append(pktdump);
    }
    
    $(function(){ // this will be called when the DOM is ready
        $('#searchUser').on('click',function() {
            var searchstr=$('#userSearch').val();
            if(searchstr!=''){
                $.ajax({
                    type: 'POST',
                    url: "{{ route('user.search.ajax') }}",
                    data: {'searchString' :searchstr },
                    dataType: "json",
                    success: function( data ) {
                    // var pkt=$.parseJSON(data);
                        viewGenerator(data);
                    }       
                })
            }
        });
    });
   
    function viewGenerator(data){
        $("#users").empty()
        var pkt = $.parseJSON(JSON.stringify(data));
        //console.log(pkt);
        var data=pkt[0]['data'];
        var role=pkt[0]['role'];
        var length=Object.keys(data).length;
        var rolelength=Object.keys(role).length;
        var pktdump='';
        for(var i=0;i<length;i++){
             if(data[i]['id']!=1){          
                    var rolename='';
                    pktdump+="<div class='col-sm-12 col-md-4 col-lg-3 m-b-30'><div class='widget-item user'><div class='tiles user-dp'> <div class='tiles-body no-padding'><a href=''>";
                    if(data[i]['profile_picture']){
                        pktdump+="<img src='"+ data[i]['profile_picture'] +"' alt=''>";
                    }
                    else if(data[i]['gender']=='male'){
                        pktdump+="<img src='/assets/img/profiles/male-user.jpg' alt=''>";
                    }
                    else{
                        pktdump+="<img src='/assets/img/profiles/female-user.jpg' alt=''>";
                    }                                      
                    pktdump+="</a><div class='overlayer bottom-right fullwidth'><div class='overlayer-wrapper'><div class=' p-l-20 p-r-20 p-b-20 p-t-20'><div>";
                    if(data[i]['role']!=''){
                        for(j=0;j<rolelength;j++){
                            if(parseInt(data[i]['role'])==parseInt(role[j]['roleid'])){
                                rolename= role[j]['rolename']; 
                            }
                        } 
                    }
                    var id=data[i]['id'];
                    var $parameter= "<?php echo Crypt::encrypt("+id+"); ?>";
                    console.log($parameter);
                    pktdump+="</div><div class='pull-right'> <a href='{{route('edit.user','')}}/"+$parameter+"' class='hashtags'>"+ rolename +" </a> </div>";
                    pktdump+="<div class='clearfix'></div></div></div></div><br></div></div><div class='tiles white  body-tiles'>";
                    pktdump+="<div class='tiles-body'><div class='row'><div class='user-comment-wrapper pull-left'><div class='comment'><div class='user-name text-black bold'>"+data[i]['displayname']+" </div>";
                    pktdump+="<div class='preview-wrapper'>"+data[i]['designation']+"</div></div><div class='clearfix'></div></div>";                                          
                    pktdump+="<div class='clearfix'></div><div class='p-l-15 p-t-10 p-r-20'><p>"+data[i]['phone']+"</p><p><a >"+data[i]['email']+"</a></p>";
                    pktdump+="<div class='post p-t-10 p-b-10'><div class='view-btn'><a href='{{route('edit.user','')}}/"+$parameter+"' class='btn button'>Edit</a></div>";
                    pktdump+="<div class='clearfix'></div></div></div></div></div></div></div></div>";
                }
                else{
                    var rolename='';
                    pktdump+="<div class='col-sm-12 col-md-4 col-lg-3 m-b-30'><div class='widget-item user'><div class='tiles user-dp'> <div class='tiles-body no-padding'><a href=''>";
                    if(data[i]['profile_picture']){
                        pktdump+="<img src='"+ data[i]['profile_picture'] +"' alt=''>";
                    }
                    else if(data[i]['gender']=='male'){
                        pktdump+="<img src='/assets/img/profiles/male-user.jpg' alt=''>";
                    }
                    else{
                        pktdump+="<img src='/assets/img/profiles/female-user.jpg' alt=''>";
                    }                                      
                    pktdump+="</a><div class='overlayer bottom-right fullwidth'><div class='overlayer-wrapper'><div class=' p-l-20 p-r-20 p-b-20 p-t-20'><div>";
                    if(data[i]['role']!=''){
                        for(j=0;j<rolelength;j++){
                            if(parseInt(data[i]['role'])==parseInt(role[j]['roleid'])){
                                rolename= role[j]['rolename']; 
                            }
                        } 
                    }
                    var id=data[i]['id'];
                    var $parameter= "<?php echo Crypt::encrypt("+id+"); ?>";
                    console.log($parameter);
                    pktdump+="</div><div class='pull-right'> <a href='' class='hashtags'>"+ rolename +" </a> </div>";
                    pktdump+="<div class='clearfix'></div></div></div></div><br></div></div><div class='tiles white  body-tiles'>";
                    pktdump+="<div class='tiles-body'><div class='row'><div class='user-comment-wrapper pull-left'><div class='comment'><div class='user-name text-black bold'>"+data[i]['displayname']+" </div>";
                    pktdump+="<div class='preview-wrapper'>"+data[i]['designation']+"</div></div><div class='clearfix'></div></div>";                                          
                    pktdump+="<div class='clearfix'></div><div class='p-l-15 p-t-10 p-r-20'><p>"+data[i]['phone']+"</p><p><a >"+data[i]['email']+"</a></p>";
                    pktdump+="<div class='post p-t-10 p-b-10'><div class='view-btn'><a href='' class='btn button'>Edit</a></div>";
                    pktdump+="<div class='clearfix'></div></div></div></div></div></div></div></div>";
                }
        }//forloop
        $('#users').append(pktdump);
    }
    
    
    </script>

		<div class="page-content">
			<div class="content">
                    @if (session()->has('success'))
                        <div class='alert alert-success'>
                            <span class="invalid-feedback" role="alert">
                                <strong >{{ session()->get('success') }}</strong>
                            </span>
                        </div>
                    
					@endif
				<div class="page-title">
					<h3><i class="fa fa-users"></i>User List</h3>
				</div>
                <div>
                <?php //print_r($role); ?>
                </div>
				<div class="row projects-topsec">
					<div class="col-sm-12">
                            <div class="col-sm-12 col-md-8 search-column">
                                <input name="userSearch" type="text" id='userSearch' class="user-search" placeholder="Search for users..." value="{{ old('fullname') }}">
                                <button type="button" id='searchUser' class="btn btn-search btn-cons"><i class="fa fa-search"></i></button>
                            </div>
                        
						<div class="col-sm-12 col-md-4 create-btn-colum">
							<a href="{{ route('create.user') }}" class="btn btn-create btn-cons pull-right"><i class="fa fa-plus"></i> Create new user</a>
						</div>
					</div>
			    </div>
                
                <div id="users" class="row">
                    @foreach ($data as $user)
                        @if($user->id!=1)
                            <div class="col-sm-12 col-md-4 col-lg-3 m-b-30">
                                    <div class="widget-item user ">
                                            <div class="tiles user-dp">
                                                <div class="tiles-body no-padding">
                                            
                                                        <a href="{{route('edit.user',Crypt::encrypt($user->id))}}">
                                                        
                                                            @if($user->profile_picture!='')
                                                                <img src="{{ asset($user->profile_picture) }}" alt="">
                                                            
                                                            @else
                                                                @if($user->gender!='')
                                                                    @if($user->gender==='male')
                                                                        <img src="/assets/img/profiles/male-user.jpg" alt="">    
                                                                    @else
                                                                        <img src="/assets/img/profiles/female-user.jpg" alt="">    
                                                                    @endif                                                                
                                                                @else
                                                                    <img src="/assets/img/profiles/user.jpg" alt="">                                                                          
                                                                @endif                                                             
                                                            @endif
                                                        
                                                    {{-- <img src="{{ $user->profile_picture }}" alt=""> --}}
                                                        
                                                        
                                                        </a>
                                                        <div class="overlayer bottom-right fullwidth">
                                                            <div class="overlayer-wrapper">
                                                                    <div class=" p-l-20 p-r-20 p-b-20 p-t-20">
                                                                    <div><?php 
                                                                            $rolename='';
                                                                            foreach($role as $rolepkt){
                                                                                    if($rolepkt->roleid==$user->role){
                                                                                        $rolename=$rolepkt->rolename;
                                                                                    }
                                                                                } 
                                                                            ?></div>
                                                                        
                                                                            @if($rolename)
                                                                                    <div class="pull-right"> <a href="{{route('edit.user',Crypt::encrypt($user->id))}}" class="hashtags"> {{ $rolename }} </a> </div>
                                                                            @else
                                                                                    <div class="pull-right"> <a href="{{route('edit.user',Crypt::encrypt($user->id))}}" class="hashtags hashtags-blue"> No Role Assigned </a> </div>
                                                                            @endif
                                                                        
                                                                        
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                            </div>
                                                        </div>
                                                        <br>
                                                </div>
                                            </div>
                                            <div class="tiles white body-tiles">
                                                <div class="tiles-body">
                                                    <div class="row">
                                                        <div class="user-comment-wrapper pull-left">
                                                            
                                                            <div class="comment">
                                                                <div class="user-name text-black bold">{{ $user->displayname }} {{--<span class="semi-bold">{{ $user->displayname }}</span>--}}</div>
                                                                <div class="preview-wrapper">{{ $user->designation }}</div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    
                                                        <div class="clearfix"></div>
                                                            <div class="p-l-15 p-t-10 p-r-20">
                                                                    <p>{{ $user->phone }}</p>
                                                                    <p><a >{{ $user->email }}</a></p>
                                                                    <div class="post p-t-10 p-b-10">
                                                                    <div class="view-btn"><a href="{{route('edit.user',Crypt::encrypt($user->id))}}" class="btn button">Edit</a></div>
                                                                    
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @else
                                    <div class="col-sm-12 col-md-4 col-lg-3 m-b-30">
                                        <div class="widget-item user ">
                                                <div class="tiles user-dp">
                                                    <div class="tiles-body no-padding">
                                                
                                                            <a href="">
                                                            
                                                                @if($user->profile_picture!='')
                                                                    <img src="{{ asset($user->profile_picture) }}" alt="">
                                                                
                                                                @else
                                                                    @if($user->gender!='')
                                                                        @if($user->gender==='male')
                                                                            <img src="/assets/img/profiles/male-user.jpg" alt="">    
                                                                        @else
                                                                            <img src="/assets/img/profiles/female-user.jpg" alt="">    
                                                                        @endif                                                                
                                                                    @else
                                                                        <img src="/assets/img/profiles/user.jpg" alt="">                                                                          
                                                                    @endif                                                             
                                                                @endif
                                                            
                                                       
                                                            
                                                            </a>
                                                            <div class="overlayer bottom-right fullwidth">
                                                                <div class="overlayer-wrapper">
                                                                        <div class=" p-l-20 p-r-20 p-b-20 p-t-20">
                                                                        <div><?php 
                                                                                $rolename='';
                                                                                foreach($role as $rolepkt){
                                                                                        if($rolepkt->roleid==$user->role){
                                                                                            $rolename=$rolepkt->rolename;
                                                                                        }
                                                                                    } 
                                                                                ?></div>
                                                                            
                                                                                @if($rolename)
                                                                                        <div class="pull-right"> <a href="" class="hashtags"> {{ $rolename }} </a> </div>
                                                                                @else
                                                                                        <div class="pull-right"> <a href="" class="hashtags hashtags-blue"> No Role Assigned </a> </div>
                                                                                @endif
                                                                            
                                                                            
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                            <br>
                                                    </div>
                                                </div>
                                                <div class="tiles white body-tiles">
                                                    <div class="tiles-body">
                                                        <div class="row">
                                                            <div class="user-comment-wrapper pull-left">
                                                                
                                                                <div class="comment">
                                                                    <div class="user-name text-black bold">{{ $user->displayname }} {{--<span class="semi-bold">{{ $user->displayname }}</span>--}}</div>
                                                                    <div class="preview-wrapper">{{ $user->designation }}</div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                        
                                                            <div class="clearfix"></div>
                                                                <div class="p-l-15 p-t-10 p-r-20">
                                                                        <p>{{ $user->phone }}</p>
                                                                        <p><a href="">{{ $user->email }}</a></p>
                                                                        <div class="post p-t-10 p-b-10">
                                                                        <div class="view-btn"><a href="" class="btn button">Edit</a></div>
                                                                        
                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    @endif
				            
			            
                    @endforeach
                    
                    </div>
                    </div>

				
				
				

	</div>
	</div>

    <!-- {{ Html::script('js/jquery.matchHeight.js') }} -->
	
    
@endsection
</body>
</html>





















{{--
					<div id="users" class="row">
                        <div class="col-sm-12 col-md-4 col-lg-3 m-b-10">
                            <div class="widget-item user ">
                                    <div class="tiles user-dp">
                                        <div class="tiles-body no-padding">
                                                <a href="edit-user-profile.php"><img src="../assets/img/profiles/arshad-small.jpg" alt=""></a>
                                                <div class="overlayer bottom-right fullwidth">
                                                    <div class="overlayer-wrapper">
                                                            <div class=" p-l-20 p-r-20 p-b-20 p-t-20">
                                                                <div class="pull-right"> <a href="edit-user-profile.php" class="hashtags"> Administrator </a> </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                    </div>
                                                </div>
                                                <br>
                                        </div>
                                    </div>
                                    <div class="tiles white  body-tiles">
                                        <div class="tiles-body">
                                            <div class="row">
                                                <div class="user-comment-wrapper pull-left">
                                                    
                                                    <div class="comment">
                                                        <div class="user-name text-black bold"> Arshad <span class="semi-bold">Arsal</span> </div>
                                                        <div class="preview-wrapper">Designer</div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            
                                                <div class="clearfix"></div>
                                                    <div class="p-l-15 p-t-10 p-r-20">
                                                            <p>+973 3397 4241</p>
                                                            <p><a href="mailto:arshad@akit.me">arshad@akit.me</a></p>
                                                            <div class="post p-t-10 p-b-10">
                                                                <div class="view-btn"><a href="edit-user-profile.php" class="btn button">View</a></div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
				            </div>
			            </div>
    

		</div>
	</div>
@endsection
</body>
</html>
--}}