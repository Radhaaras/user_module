<!DOCTYPE html>
@extends('layouts.app')
@section('content')
<script>

$(function(){ // this will be called when the DOM is ready
	$('.rolestatus').on('click', function(){
		var rolestatus=$(this).val();
		
			$.ajax({
				type: 'POST',
				url: "{{ route('role.view.status.change') }}",
				data: {'rolestatus':rolestatus,"_token": "{{ csrf_token() }}", },
				dataType: "json",
				success: function( data ) {
					var pkt='';
					if(data.error){
						pkt="<div class='alert alert-warning'><span class='invalid-feedback' role='alert'><strong >"+ data.error +",  Refresh the page to see update</strong></span></div>";
					}
					if(data.success){
						pkt="<div class='alert alert-success'><span class='invalid-feedback' role='alert'><strong >"+ data.success +",  Refresh the page to see update</strong></span></div>";
					}
					
					$('#msgdisp').html(pkt);
					
				}       
			})
		});
});
	
$("#roleSearch").keyup(function() {
	$rolename=$('#roleSearch').val();
	if($rolename!=''){

	}

})

$(function(){ // this will be called when the DOM is ready
       $("#roleSearch").keyup(function() {
			var rolename=$('#roleSearch').val();
			$.ajax({
				type: 'POST',
				url: "{{ route('search.role.ajax') }}",
				data: {'rolesearch':rolename,"_token": "{{ csrf_token() }}", },
				dataType: "json",
				success: function( data ) {
					console.log(data);
					viewGenerator(data);
				}       
			})	
		});
    });
   
    function viewGenerator(data){
        $("#tableBodyDisplay").empty()
        var pkt = $.parseJSON(JSON.stringify(data));
        var role=pkt[0]['role'];
        var user=pkt[0]['user'];
		var rolelength=Object.keys(role).length;
		var userlength=Object.keys(user).length;
		//console.log(role);
		//console.log(user);
		//console.log(rolepermission)->menuid;
        var tmp=['Project','Estimate','Quotation','Invoice','Joborder','Delivery Note','Payment and  Receipt','Clients','Reports','Employee','Settings','Supervisor'];
        var access=['selectall','view','create','edit','print','delete'];
		pktdump="";
       if(rolelength>0){
		  // console.log(role);
			for(var i=0;i<rolelength;i++){
				//console.log(role[i]);
				//console.log(role[i]['status']);
				pktdump+="<tr><td class='v-align-middle'>";
				if(role[i]['created_by'] == 'system'){
					if(role[i]['status']==1){
						pktdump+="<label class='user-role-switch disabled' >";
						pktdump+="<input type='checkbox' checked id='systemrolecheckbox' class='rolestatus disabled' name='rolestatus' value='"+role[i]['roleid']+"-1 ' >";
					}
					else{
						pktdump+="<label class='user-role-switch disabled' >";
						pktdump+="<input type='checkbox' class='rolestatus' name='rolestatus' value='"+role[i]['roleid']+"-0'  disabled>";
					}
				}
				else{
					if(role[i]['status']==1){
						pktdump+="<label class='user-role-switch disabled' >";
						pktdump+="<input type='checkbox' checked class='rolestatus' name='rolestatus' value='"+role[i]['roleid']+"-1 '  disabled>";
					}
					else{
						pktdump+="<label class='user-role-switch disabled' >";
						pktdump+="<input type='checkbox' class='rolestatus' name='rolestatus' value='"+role[i]['roleid']+"-0'  disabled>";
					}
				}
				pktdump+="<span class='slider-user-role disabled'></span></label></td><td class='v-align-middle'> "+ role[i]['rolename']+"</td>";							
				if(role[i]['created_by']=='system'){
					pktdump+="<td class='v-align-middle'>"+role[i]['created_by']+"</td>";
				}
				else{
					for(j=0;j<userlength;j++){
						//console.log(user[j]);
						if(user[j]['id']==role[i]['created_by']){
							pktdump+="<td class='v-align-middle'>"+user[j]['displayname']+"</td>";
							break;
						}		
					}
				}
				console.log(role[i]['created_at']);
				var datetmp=role[i]['created_at'].split(' ');
				var datetmp2=datetmp[0].split('-');
				
				pktdump+="<td class='v-align-middle'>"+datetmp2[2]+"-"+datetmp2[1]+"-"+datetmp2[0]+"</td>";
				
				if(role[i]['created_by'] == 'system'){
					var authuserrole="<?php echo Auth::user()->role; ?>";
					//alert(authuserrole);
												
					if(authuserrole == 1){

						var $parameter= "<?php echo Crypt::encrypt("+role[i]['roleid']+"); ?>";
            			pktdump+="<td class='v-align-middle'><a class='btn-edit-icon' href='{{ route('view.role.admin','')}}/"+$parameter+"' ><i class='far fa-eye'></i></a></td>";
						//pktdump+="<td class='v-align-middle'><a class='btn-delete-icon' href='{{ route('edit.role','')}}/"+$parameter+"' ><i class='far fa-trash-alt'></i></a></td>";
						
					}
					else{
						
						pktdump+="<td class='v-align-middle'><a class='btn-edit-icon' href='' ></a></td>";
						pktdump+="<td class='v-align-middle'><a class='btn-delete-icon' href='' ></a></td>";
						
					} 
				}else{
						var $parameter= "<?php echo Crypt::encrypt("+role[i]['roleid']+"); ?>";
						pktdump+="<td class='v-align-middle'><a class='btn-edit-icon' href='{{ route('edit.role','')}}/"+$parameter+"' ><i class='far fa-edit'></i></a></td>";
						pktdump+="<td class='v-align-middle'><a class='btn-delete-icon' href='{{ route('delete.role','')}}/"+role[i]['roleid']+"' ><i class='far fa-trash-alt'></i></a></td>";
						
				}	



				
				//pktdump+="<td class='v-align-middle'><a class='btn-edit-icon' href='{{route('edit.role','')}}/"+role[0]['roleid']+"' ><i class='far fa-edit'></i></a></td>";
				//pktdump+="<td class='v-align-middle'><a class='btn-delete-icon' href='{{route('edit.role','')}}/"+role[0]['roleid']+"' ><i class='far fa-trash-alt'></i></a></td>";
				pktdump+="</tr>";
												
							
			}	
		 }//forloop
        $('#tableBodyDisplay').append(pktdump);
		
    }
</script>
	
		<div class="page-content">
			<div class="content">
				<div id='msgdisp'></div>
					@if (session()->has('failed'))
					<div class='alert alert-warning'>
							<span class="invalid-feedback" role="alert">
									<strong >{{ session()->get('failed') }}</strong>
							</span>
					</div>
                    
					@endif
					@if (session()->has('success'))
					<div class='alert alert-success'>
							<span class="invalid-feedback" role="alert">
									<strong >{{ session()->get('success') }}</strong>
							</span>
					</div> 
                    
					@endif
					
				<div class="page-title">
					<h3><i class="fa fa-plug"></i> Role Settings</h3>
				</div>
				
				<div class="row projects-topsec">
					<div class="container">
					
							<div class="col-sm-12">
								
									<div class="col-sm-12 col-md-8 search-column">
										<input name="roleSearch" id="roleSearch" type="text" class="user-search" placeholder="Search roles...">
										<button type="button" class="btn btn-search btn-cons"><i class="fa fa-search"></i></button>
									</div>
									
									<div class="col-sm-12 col-md-4 create-btn-colum">
										<a href="{{ route('create.role') }}" class="btn btn-create btn-cons pull-right"><i class="fa fa-plus"></i> Create a new role</a>
									</div>
							</div>
					</div>
					
				</div>
				
				
				
				<div id="role-settings" class="row">


					<div class="container">
						
						<div class="col-sm-12">
						  <div class="grid simple ">

							<div class="grid-body no-border role-settings-table">

							  <table class="table">
								<thead>
								<tr>
									<th style="width: 2%;">Status</th>
									<th style="width: 25%;">Role Name</th>
									<th style="width: 5%;">Created By</th>
									<th style="width: 5%;">created On</th>
									<th style="width: 0.1%;"></th>
									<th style="width: 0.1%;"></th>
								  </tr>
								</thead>
								<tbody id='tableBodyDisplay'>
								@foreach ($role as $roles)
								
								
										<tr>
											<td class="v-align-middle">
												@if($roles->created_by=='system')
													<label class="user-role-switch ">
													@if($roles->status)
														<input type="checkbox" checked id="systemrolecheckbox" class='rolestatus disabled' name='rolestatus[]' value='{{ $roles->roleid  }}-1 '>
													@else
														<input type="checkbox"  class='rolestatus' name='rolestatus[]' value='{{ $roles->roleid }}-0 '>
													@endif
														<span class="slider-user-role disabled" ></span>
													</label>
												@else
													<label class="user-role-switch">
													@if($roles->status)
														<input type="checkbox" checked  class='rolestatus' name='rolestatus[]' value='{{ $roles->roleid  }}-1 '>
													@else
														<input type="checkbox"  class='rolestatus' name='rolestatus[]' value='{{ $roles->roleid }}-0 '>
													@endif
														<span class="slider-user-role" ></span>
													</label>
												@endif
											</td>
											<td class="v-align-middle">{{ $roles->rolename }}</td>
											@if($roles->created_by=='system')
													<td class="v-align-middle">{{ $roles->created_by }}</td>
											@else
												<?php
														foreach($user as $users){
																if($users->id==$roles->created_by){
																		$name= $users->displayname;
																		break;
																}
														}
												?>						

													<td class="v-align-middle">{{ $name }}</td>
											@endif
											<?php 
												$date=date('d-m-Y',strtotime($roles->created_at));
											?>

											<td class="v-align-middle">{{ $date }}</td>
											
											<?php 

												if($roles->created_by == 'system'){
												
													if(Auth::user()->role == 1){
														
														?>
														
															<td class="v-align-middle"><a class="btn-edit-icon" href="{{ route('view.role.admin', Crypt::encrypt($roles->roleid)) }}" ><i class="far fa-eye"></i></a></td>
															<!-- <td class="v-align-middle"><a class="btn-delete-icon" href="{{ route('view.role.admin', Crypt::encrypt($roles->roleid)) }}" ><i class="far fa-eye"></i></a></td> -->
														<?php
													}
													else{
														?>
															<td class="v-align-middle"><a class="btn-edit-icon" href="" ></a></td>
															<td class="v-align-middle"><a class="btn-delete-icon" href="" ></a></td>
														<?php
													} 
												}else{
													?>
														<td class="v-align-middle"><a class="btn-edit-icon" href="{{ route('edit.role', Crypt::encrypt($roles->roleid)) }}" ><i class="far fa-edit"></i></a></td>
														<td class="v-align-middle"><a class="btn-delete-icon" href="{{ route('delete.role', $roles->roleid) }}" ><i class="far fa-trash-alt"></i></a></td>
													<?php
												}
												?>
												</tr>

												@endforeach
								  
								</tbody>
							  </table>
							</div>
						  </div>
						</div>
						
					</div>
					
					



				</div>
				
				
				
				
			</div>
		</div>
		
		
		

	</div>
<script>
	document.getElementById("systemrolecheckbox").disabled = true;

</script>
<!--
	<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery/jquery-3.3.1.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="../quofly/js/quofly.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="../assets/plugins/jquery-flot/jquery.flot.js" type="text/javascript"></script>
	-->
	@stop
</body>
</html>