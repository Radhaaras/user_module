<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>

	<link rel="icon" type="image/png" href="{{ URL::asset('assets/img/favicon.png')}}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/font-awesome/css/font-awesome.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/pace/pace-theme-flash.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/bootstrapv3/css/bootstrap.min.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/bootstrapv3/css/bootstrap-theme.min.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('https://fonts.googleapis.com/icon?family=Material+Icons') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/animate.min.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/plugins/jquery-scrollbar/jquery.scrollbar.css') }}" />
	<link rel="stylesheet" type="text/css" href="{{ URL::asset('quofly/css/quofly.css') }}" />

</head>

<body class="login-screen no-top lazy">
	<div class="container">
		<div class="row login-container animated fadeInUp">
        	<div class="col-md-6 col-md-offset-3 tiles white no-padding">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
				<div class="p-t-30 p-b-20 login-logo">
					<a href=""><img src="{{ URL::asset('assets/img/logo/logo.svg') }}" alt=""></a>
				</div>
				
				<div class="tiles white p-t-20 p-b-20 no-margin text-black tab-content">
					<h1 class="text-center">Forgot password?</h1>
					<p class="text-center">To reset your password, enter your email address associated with your account. We will send you a password reset link.</p>
					<div role="tabpanel" class="tab-pane active" id="tab_login">
						<form class="animated fadeIn validate" method="POST" action="{{ route('password.email') }}" aria-label="{{ __('Reset Password') }}">
                        @csrf
							<div class="row form-row m-l-20 m-r-20 xs-m-l-10 xs-m-r-10">
								<div class="col-md-12 col-sm-12">
									{{-- <input class="form-control forgot-input" id="login_username" name="login_username" placeholder="jhon@quofly.com" type="email" required>--}}
									<input id="email" type="email" placeholder="jhon@quofly.com" class="form-control  forgot-input {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ $email ?? old('email') }}" required autofocus>

									
                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif

									<button type="submit"  class="btn forgot-btn-send">{{ __('Submit') }}</button>
									<a href="{{ route('login') }}" class="login-link">Login</a>
								</div>
							</div>
							
							
							
							<div class="row m-t-50 m-b-25">
									<div class="col-sm-12 login-bottom-logo text-center">
										<h2>Powered By</h2>
										<a href="#"><img src="assets/img/logo.svg" alt=""></a>
									</div>
							</div>
							
						</form>
					</div>
					
					
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/pace/pace.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery/jquery-1.11.3.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/bootstrapv3/js/bootstrap.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery-block-ui/jqueryblockui.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery-unveil/jquery.unveil.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/jquery-validation/js/jquery.validate.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/plugins/bootstrap-select2/select2.min.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('quofly/js/quofly.js') }}" />
	<script type="text/javascript" href="{{ URL::asset('assets/js/chat.js') }}" />

</body>
</html>