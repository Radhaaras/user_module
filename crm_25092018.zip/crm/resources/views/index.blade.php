<!DOCTYPE html>
<html>
<head>

	<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
	<meta charset="utf-8"/>
	<title>QUOFLY - Enterprise Resource Planning, ERP System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<meta content="" name="Enterprise Resource Planning, ERP System"/>
	<meta content="" name="AK Information Technology Bahrain"/>

	<link rel="icon" type="image/png" href="assets/img/favicon.png" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
	<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
	<link href="assets/plugins/bootstrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="assets/plugins/animate.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
	<link href="quofly/css/quofly.css" rel="stylesheet" type="text/css"/>

</head>

<body class="login-screen no-top lazy">
	<div class="container">
		<div class="row login-container animated fadeInUp">
			<div class="col-md-6 col-md-offset-3 tiles white no-padding">
			

			@if (session()->has('error'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('error') }}</strong>
						</span>
					</div>
					@endif

				@if (session()->has('status'))
					<div class='alert alert-success'>
						<span class="invalid-feedback" role="alert">
							<strong >{{ session()->get('status') }}</strong>
						</span>
					</div>
					@endif
					
				<div class="p-t-30 p-b-20 login-logo">
					<img src="assets/img/logo/logo.svg" alt="">
				</div>
				<div class="tiles white p-t-20 p-b-20 no-margin text-black tab-content">
					
					<div role="tabpanel" class="tab-pane active" id="tab_login">
						<form class="animated fadeIn validate" id="" name="" method="POST" action="{{ route('login.submit')  }}" aria-label="{{ __('Login') }}">
							@csrf
							<div class="row form-row m-l-20 m-r-20 xs-m-l-10 xs-m-r-10">
								<div class="col-md-12 col-sm-12">
								<!--	<input class="form-control login-input" id="login_username" name="login_username" placeholder="Username" type="email" required>
								-->
								<input id="email" type="email" placeholder="Email address"  class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}  login-input" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif

								</div>
								<div class="col-md-10 col-sm-10 m-t-10">
									<!--<input class="form-control login-input" id="login_pass" name="login_pass" placeholder="Password" type="password" required>
									@if ($errors->has('password'))
											<span class="invalid-feedback" role="alert">
												<strong>{{ $errors->first('password') }}</strong>
											</span>
										@endif
									-->
									 
										<input id="login_pass" type="password" name="password" class="form-control login-input {{ $errors->has('password') ? ' is-invalid' : '' }}" required placeholder="Password">

										@if ($errors->has('password'))
											<span class="invalid-feedback" role="alert">
												<strong>{{ $errors->first('password') }}</strong>
											</span>
										@endif
									 
									
								</div>
								<div class="col-md-2 col-sm-2 m-t-10">
									<button type="submit" class="btn btn-login pull-right"><i class="fa fa-arrow-right"></i></button>
								</div>
							</div>
							
							<div class="row p-t-10 m-l-30 m-r-20 xs-m-l-10 xs-m-r-10">
								<div class="control-group col-md-12">
									<div class="checkbox checkbox check-success">
										<!--<input id="checkbox1" name='rememberme' type="checkbox" value="1" hidden>
										<label for="checkbox1" hidden>Keep me reminded</label>-->
										<a href="{{ route('password.request') }}" class="">Forgot password?</a>
									</div>
								</div>
							</div>
							
							<div class="row m-t-50 m-b-25">
									<div class="col-sm-12 login-bottom-logo text-center">
										<h2>Powered By</h2>
										<a href="#"><img src="assets/img/logo.svg" alt=""></a>
									</div>
							</div>
							
						</form>
					</div>
					
					
				</div>
			</div>
		</div>
	</div>
	
	<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
	
	<script src="assets/plugins/jquery/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrapv3/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-block-ui/jqueryblockui.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
	<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
	
	<script src="quofly/js/quofly.js" type="text/javascript"></script>
	<script src="assets/js/chat.js" type="text/javascript"></script>
	
</body>
</html>