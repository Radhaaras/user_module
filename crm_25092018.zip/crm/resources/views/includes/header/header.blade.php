
{{--
	
    {{ Html::style('assets/img/favicon.png') }}
    {{ Html::style('https://use.fontawesome.com/releases/v5.1.0/css/all.css') }}
    
    {{ Html::style('assets/plugins/pace/pace-theme-flash.css') }}
    {{ Html::style('assets/plugins/bootstrapv3/css/bootstrap.min.css') }}
    {{ Html::style('assets/plugins/bootstrapv3/css/bootstrap-theme.min.css') }}
    {{ Html::style('https://fonts.googleapis.com/icon?family=Material+Icons') }}
    {{ Html::style('assets/plugins/animate.min.css') }}
    {{ Html::style('assets/plugins/jquery-scrollbar/jquery.scrollbar.css') }}
    {{ Html::style('quofly/css/quofly.css') }}
    
	{{ Html::style('assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.css') }}
    {{ Html::style('assets/plugins/bootstrap-datepicker/css/datepicker.css') }}
    {{ Html::style('assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css') }}
    {{ Html::style('assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css') }}
   
   --}}
   {{ Html::style('https://use.fontawesome.com/releases/v5.1.0/css/all.css') }}
   {{ Html::style('assets/plugins/pace/pace-theme-flash.css') }}
   {{ Html::style('assets/plugins/bootstrapv3/css/bootstrap.min.css') }}
   {{ Html::style('assets/plugins/bootstrapv3/css/bootstrap-theme.min.css') }}
   {{ Html::style('https://fonts.googleapis.com/icon?family=Material+Icons') }}
   {{ Html::style('assets/plugins/animate.min.css') }}
   {{ Html::style('assets/plugins/jquery-scrollbar/jquery.scrollbar.css') }}
   {{ Html::style('quofly/css/quofly.css') }}
   
	
   {{ Html::script('assets/plugins/jquery/jquery-3.3.1.min.js') }}


   
</head>