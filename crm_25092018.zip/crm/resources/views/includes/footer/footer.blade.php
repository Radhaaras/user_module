
	
	{{ Html::script('assets/plugins/pace/pace.min.js') }}
	{{ Html::script('assets/plugins/bootstrapv3/js/bootstrap.min.js') }}
	{{ Html::script('assets/plugins/jquery-block-ui/jqueryblockui.min.js') }}
	{{ Html::script('assets/plugins/jquery-unveil/jquery.unveil.min.js') }}
	{{ Html::script('assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}
	{{ Html::script('assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js') }}
	{{ Html::script('assets/plugins/jquery-validation/js/jquery.validate.min.js') }}
	{{ Html::script('quofly/js/quofly.js') }}
	{{ Html::script('assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js') }}
	{{ Html::script('assets/plugins/jquery-flot/jquery.flot.js') }}
	{{ Html::script('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js') }}
	{{ Html::script('assets/plugins/ios-switch/ios7-switch.js') }}
	{{ Html::script('assets/plugins/bootstrap-select2/select2.min.js') }}
	{{ Html::script('assets/js/form_validations.js') }}
	{{ Html::script('assets/js/form_elements.js') }}
	
	<script>
    $('.user-dp').matchHeight();
    $('.body-tiles').matchHeight();
	</script>





	<script>
	
	$( document ).ready(function() {
		//console.log( "ready!" );
		$('.expdate').datepicker({
			dateFormat: 'dd-mm-yy',
			showOtherMonths: true,
			selectOtherMonths: true
		});
		
	
	});

	setTimeout(function(){ 
		alert("Your Session is out"); 
		location.reload();
	}, 
	<?php echo \Config::get('session.lifetime') * 60 * 1000; ?>);

	console.log( <?php echo \Config::get('session.lifetime') * 60 *1000; ?> );
	</script>
