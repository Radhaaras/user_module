


<div class="page-sidebar" id="main-menu">
			
	<div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
		<!-- User Profile -->
		<a href="{{ route('user.profile') }}">
			<div class="user-info-wrapper sm">
				<div class="profile-wrapper sm">
					@if(Auth::user()->profile_picture!='')
						<img src="{{ asset(Auth::user()->profile_picture) }}" alt="">
					
					@else
						
						@if(Auth::user()->gender =='male')
							<img name='display_pic' id='profile_pic' src="/assets/img/profiles/male-user.jpg" alt="">    
						@else
							<img name='display_pic' id='profile_pic' src="/assets/img/profiles/female-user.jpg" alt="">    
						@endif                                                                
																								
					@endif                                                             
				
<!--					<img src="../assets/img/profiles/arshad-small.jpg" alt="" />-->
				</div>
				<div class="user-info sm">
					<div class="username">{{ Auth::user()->displayname }}</span></div>
					<div class="status">{{ Auth::user()->email }}</div>
				</div>
			</div>
		</a>
		<ul>
		<?php 
		//echo $active;
			$currentUrl = ( !empty($active)  ) ? $active : '';
		    if( $currentUrl !='' ){
				$currentUrl = explode('-',$currentUrl);
			}
			//print_r($currentUrl);
			$logeduser = (array) json_decode($logedInuser); 
			//$logeduser = (array) json_decode($logedUser); 
			$userPageCount= count($logeduser);
			$userMenuCount= count($dashboardMenu);

		//	print_r($dashboardMenu)	;		
		//	print_r($logeduser);
		//	exit;
			for($i = 0; $i<$userPageCount; $i++){ //<!--mAIN fOR lOOP eND-->
				
				$dcount=array_depth($dashboardMenu[$logeduser[$i]->menuid]);
					//echo $i." ".$dcount."<br>";
					
				if($dcount==1){
						
					if( Request::path() == $dashboardMenu[$logeduser[$i]->menuid]['name'] ){
						$class = 'active';
					}else{
						$class = '';
					}
					echo "<li class='".$class."'>
							<a href='";
							if($dashboardMenu[$logeduser[$i]->menuid]['route']!=''){
								echo route($dashboardMenu[$logeduser[$i]->menuid]['route']);
							}
							else{
								echo "";
							}
							
							echo "' > 
								<i class='".$dashboardMenu[$logeduser[$i]->menuid]['iclass']."' ></i> 
								<span class='".$dashboardMenu[$logeduser[$i]->menuid]['spanclass']."' >
									".$dashboardMenu[$logeduser[$i]->menuid]['menuName']." 						
								</span>
							</a>									 
						<li>";
				

				}
				elseif($dcount==3){
				//if($logeduser[$i]->menuid > 1 and $logeduser[$i]->menuid < 8)	{		
					//print_r($dashboardMenu[$logeduser[$i]->menuid]);
					
					$subLevel = $dashboardMenu[$logeduser[$i]->menuid]['submenu'];
					$subLevel = ( $subLevel != 0 ) ? $dashboardMenu[$logeduser[$i]->menuid]['submenu'] : array();
					
					if( $subLevel != 0 && Request::path() == $dashboardMenu[$logeduser[$i]->menuid]['name'] ){
						$class = 'open';
					}else{
						$class = '';
					}
						
					$newArrayCount='';
						if(is_array($dashboardMenu[$logeduser[$i]->menuid]['submenu'])){ //<!-- sUB 1 IF lOOP START-->
							$newArrayCount=count($dashboardMenu[$logeduser[$i]->menuid]['submenu']);
							echo "<li class='".$class."'>
								<a href='' > 
									<i class='".$dashboardMenu[$logeduser[$i]->menuid]['iclass']."' ></i> 
									<span class='".$dashboardMenu[$logeduser[$i]->menuid]['spanclass']."' >
										".$dashboardMenu[$logeduser[$i]->menuid]['menuName']."						
									</span>
									<span class='arrow'></span>
								</a><ul class='sub-menu'>";
							
								for($j=0; $j<$newArrayCount; $j++){ //<!-- FOR lOOP 1 START-->
									if($j==0){
										if($logeduser[$i]->create){
											echo "<li>
												<a href='";
												if($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']){
													echo route($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']);
												}
												echo "'   > 
													<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['spanclass']."' >
														".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['menuName']."						
													</span>
												</a>									 
											<li>";
										}
									}
									if($j==1){
										if($logeduser[$i]->view){
											echo "<li>
												<a href='";
												if($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']){
													echo route($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']);
												}
												echo "'   > 
													<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['spanclass']."' >
														".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['menuName']."						
													</span>
												</a>									 
											<li>";
										}
									}
									
									
								} ////<!-- FOR lOOP 1 END-->
								echo "</ul></li>";
								
						} //<!-- sUB 1 IF lOOP eND-->
							
						}
						elseif($dcount==5){ //<!-- mAIN ELSE lOOP START-->
							$newArrayCount='';
							if(is_array($dashboardMenu[$logeduser[$i]->menuid]['submenu'])){ // SUB 2 IF LOOP START
								$newArrayCount=count($dashboardMenu[$logeduser[$i]->menuid]['submenu']);
								$subLevel = $dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'];
								$subLevel = ( $subLevel != 0 ) ? $dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'] : array();
								$key = recursive_array_search(Request::path(),$dashboardMenu[$logeduser[$i]->menuid]['submenu']);
								//print_r($dashboardMenu[$logeduser[$i]->menuid]['submenu']);
								if( !empty($currentUrl) ){
									if( recursive_array_search($currentUrl[0],$dashboardMenu[$logeduser[$i]->menuid]['submenu']) ){
										$currentUrl == true;
									}
								}
								if($key || $currentUrl ){
									$class = 'open';
									$style = 'display:block';
								}
								else{
									$class = '';
									$style = '';
								}

								
								echo "<li class='".$class."'>
										<a href='' >
										<i class='".$dashboardMenu[$logeduser[$i]->menuid]['iclass']."' ></i>
											<span class='".$dashboardMenu[$logeduser[$i]->menuid]['spanclass']." ' >
												".$dashboardMenu[$logeduser[$i]->menuid]['menuName']."					
											</span>
											<span class='arrow'></span>
										</a>";
						
								echo "<ul class='sub-menu' style='".$style."'>";	
						
						
							for($j=0; $j<$newArrayCount; $j++){ //SUB 2 FOR LOOP START
								
									//	print_r($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu']);
										$key = recursive_array_search(Request::path(),$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]);
										
										if( $key || $currentUrl ){
											$class = 'active';
											$style = 'display:block;';
										}
										else{
											$class = '';
											$style = '';
										}

										$newArrayArray='';
										if(is_array($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'])){ // SUB 3 IF LOOP START
											$newArrayArray=count($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu']);
									
										echo "<li class='".$class."'>
										<a href='' > 
											<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['spanclass']."' >
													".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['menuName'] ."						
											</span>
											<span class='arrow'></span>
										</a>		
									
										<ul class='sub-menu' style='".$style."'>";	
									
									for($k = 0; $k<$newArrayArray; $k++){ // sUB 3 FOR lOOP START
										//class='". ($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['name']== Request::path() ) ? 'active':'' .
										
										if($k==2){
											
											if(Auth::user()->id==1){
												if( $dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['name']==Request::path() ){
													$class = 'open active';
													$style = 'display:block;';
												}else{
													$class = '';
													$style = '';
												}
												echo "<li class='".$class."'><a href='" ;
					
											
												echo ( !empty($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['route']) ) ? route($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['route']) : '#';
												echo "'  > 
														<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['spanclass']."'>
															".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['menuName']."
														</span>
													</a>
												<li>";	
											}
										}
										else{
											if( $dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['name']==Request::path() ){
												$class = 'open active';
												$style = 'display:block;';
											}else{
												$class = '';
												$style = '';
											}
											echo "<li class='".$class."'><a href='" ;
				
										
											echo ( !empty($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['route']) ) ? route($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['route']) : '#';
											echo "'  > 
													<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['spanclass']."'>
														".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['submenu'][$k]['menuName']."
													</span>
												</a>
											<li>";
										}
									} // sUB 3 FOR lOOP END
									
									echo "</ul></li>";
									} // SUB 3 IF LOOP eND
									else{ //// SUB 3 ELSE LOOP START
										echo "<li><a href='";
										echo ( !empty($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']) )  ?  route($dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['route']) : '#';
										echo "'> 
												<span class='".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['spanclass']."' >
													".$dashboardMenu[$logeduser[$i]->menuid]['submenu'][$j]['menuName']."						
												</span>
											</a>	
										</li>";
										
									} //// SUB 3 ELSE LOOP END
								}	////SUB 2 FOR LOOP end
								echo "</ul>";
							} // SUB 2 IF LOOP END
							
						echo "</li>";
				}//<!--mAIN ELSE lOOP END	-->
			}//<!-- mAIN fOR lOOP eND-->
		echo "<li><a href=". route('logout') ."><i class='fa fa-sign-out-alt'></i><span class='title'>Logout</span></a></li>";
		echo "</ul>";


?>

		<div class="clearfix"></div>
	

	

</div>
</div>

<?php

function is_in_array($array, $key, $key_value){
	$within_array = 'no';
	foreach( $array as $k=>$v ){
	  if( is_array($v) ){
		  $within_array = is_in_array($v, $key, $key_value);
		  if( $within_array == 'yes' ){
			  break;
		  }
	  } else {
			  if( $v == $key_value && $k == $key ){
					  $within_array = 'yes';
					  break;
			  }
	  }
	}
	return $within_array;
}
function array_depth(array $array) {
    $max_depth = 1;

    foreach ($array as $value) {
        if (is_array($value)) {
            $depth = array_depth($value) + 1;

            if ($depth > $max_depth) {
                $max_depth = $depth;
            }
        }
    }

    return $max_depth;
}
function recursive_array_search($needle,$haystack) {
    foreach($haystack as $key=>$value) {
        $current_key=$key;
        if($needle===$value OR (is_array($value) && recursive_array_search($needle,$value) !== false)) {
            return $current_key;
        }
    }
    return false;
}